#include <iostream>
#include <vector>

using namespace std;

int main()
{
    // Get n integers.
    cout << "Enter n integers: ";
    vector<int> mother_list;
    int n(0);
    while (cin >> n)
        mother_list.push_back(n);


   
    for (int i(1); i <= n; ++i)
    {
    }

    return 0;
}